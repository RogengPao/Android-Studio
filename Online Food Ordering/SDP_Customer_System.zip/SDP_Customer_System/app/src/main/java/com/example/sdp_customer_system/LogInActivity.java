package com.example.sdp_customer_system;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.Classes.DataConverter;
import com.Classes.SessionManager;
import com.Classes.UserClass;

public class LogInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
    }
    public void redirectToSignUp(View v) {
        Intent intent = new Intent(LogInActivity.this, SignUpActivity.class);
        startActivity(intent);
    }
    public void login(View view) {

        EditText username = findViewById(R.id.loginUsername);
        EditText password = findViewById(R.id.loginPassword);

        boolean validateLogins = false;

        for (UserClass i : DataConverter.getInstance().getCustomerObservableList()) {
            Log.d("Data", i.getCust_email() + i.getCust_password());
          if (i.getCust_email().equals(username.getText().toString()) && i.getCust_password().equals(password.getText().toString())) {
              SessionManager sessionManager = SessionManager.getInstance();
              sessionManager.set("cust_id", i.getCust_id());
              sessionManager.set("cust_username", i.getCust_fname() + " " + i.getCust_lname());
              sessionManager.set("cust_email", i.getCust_email());
              sessionManager.set("cust_password", i.getCust_password());
              validateLogins = true;
           }
        }
        if (validateLogins) {
            Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
            Log.d("Login Success", "Failed Success");
            Intent intent = new Intent(LogInActivity.this, MainFrame.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
            Log.d("Login Fail", "Failed Login");
        }
    }

}