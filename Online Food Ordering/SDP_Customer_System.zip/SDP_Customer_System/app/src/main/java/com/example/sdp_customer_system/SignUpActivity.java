package com.example.sdp_customer_system;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.ObservableArrayList;

import com.Classes.DataConverter;
import com.Classes.UserClass;

import java.io.IOException;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }

    public void redirectBackToLogIn(View v) {
        Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
        startActivity(intent);
    }


    public void signUpNewAccount(View view) throws IOException {
        EditText fname = findViewById(R.id.fnameSignUp);
        EditText lname = findViewById(R.id.lnameSignUp);
        EditText email = findViewById(R.id.emailSignUp);
        EditText password = findViewById(R.id.passwordSignUp);
        EditText con_password = findViewById(R.id.confirmPasswordSignUp);
        CheckBox checkbox = findViewById(R.id.checkBoxSignUp);

        ObservableArrayList<UserClass> customerObservableList = DataConverter.getInstance().getCustomerObservableList();
        int size = 0; // Initialize with a default size if the list is null

        if (customerObservableList != null) {
            size = customerObservableList.size() + 1;
        }

        String sizeString = String.valueOf(size);


        if (signUpValidation(fname, lname, email, password, con_password, checkbox)) {
            UserClass userClass = new UserClass(sizeString, fname.getText().toString() , lname.getText().toString()
            , email.getText().toString() , password.getText().toString());
            DataConverter.getInstance().addCustomerObservableList(userClass);
            DataConverter.getInstance().storeCustomerObservableList(getApplicationContext());
            Toast.makeText(getApplicationContext(), "Sign Up Successful", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(SignUpActivity.this, LogInActivity.class);
            startActivity(intent);
        }


    }

    public Boolean signUpValidation(EditText fname, EditText lname, EditText email, EditText password, EditText confirm_pass, CheckBox checkBox) {
        boolean validated = true;
        if (fname.getText().toString().isEmpty()) {
            fname.setError("First Name is Required");
            validated = false;
        } else if (!(fname.getText().toString().length() >= 4 && fname.getText().toString().length() <= 12)) {
            validated = false;
            fname.setTextColor(Color.RED);
            fname.setError("First Name should be between 5-12 letters");
        } else {
            fname.setTextColor(Color.rgb(102, 153, 51));
        }

        if (lname.getText().toString().isEmpty()) {
            lname.setError("Last Name is Required");
            validated = false;
        } else if (!(lname.getText().toString().length() >= 4 && lname.getText().toString().length() <= 12)) {
            validated = false;
            lname.setTextColor(Color.RED);
            lname.setError("Last Name should be between 5-12 letters");
        } else {
            lname.setTextColor(Color.rgb(102, 153, 51));
        }

        boolean repeated_email = false;
        for (UserClass i : DataConverter.getInstance().getCustomerObservableList()) {
            if (i.getCust_email().equals(email.getText().toString())) {
                repeated_email = true;
            }
        }
        if (email.getText().toString().isEmpty()) {
            email.setError("Email is required");
            validated = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            email.setError("Invalid email format");
            email.setTextColor(Color.RED);
            validated = false;
        } else if (repeated_email) {
            email.setError("Email is already taken");
            email.setTextColor(Color.RED);
            validated = false;
        } else {
            email.setTextColor(Color.rgb(102, 153, 51));
        }

        if (password.getText().toString().isEmpty()) {
            password.setError("Password cannot be empty");
            validated = false;
        } else if (!(password.getText().toString().length() >= 4)) {
            password.setError("Password cannot be less than 4 letters");
            validated = false;
        }

        if (password.getText().toString().isEmpty()) {
            confirm_pass.setError("Confirm Password cannot be empty");
            validated = false;
        } else if (!confirm_pass.getText().toString().equals(password.getText().toString())) {
            confirm_pass.setError("Confirm Password is different from Password");
            validated = false;
        }

        if (!checkBox.isChecked()) {
            checkBox.setError("Need to be checked");
            validated = false;
        } else {
            checkBox.setError(null);
        }
        return validated;
    }
}