package com.Classes;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.databinding.ObservableArrayList;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class DataConverter {
    private static final DataConverter instance = new DataConverter();

    public static DataConverter getInstance() {
        return instance;
    }

//    Customer-----------------------------------------------
    ObservableArrayList<UserClass> customerObservableList;

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void loadCustomerObservableList(Context context) {
        customerObservableList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "customer_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            Log.d("File Path", file.getAbsolutePath());
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] customer_data = input.split(",");
                String cust_id = customer_data[0];
                String cust_fname = customer_data[1];
                String cust_lname = customer_data[2];
                String cust_email = customer_data[3];
                String cust_password = customer_data[4];

                UserClass userClass = new UserClass(cust_id, cust_fname, cust_lname, cust_email, cust_password);
                customerObservableList.add(userClass);
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public ObservableArrayList<UserClass> getCustomerObservableList() {
        return customerObservableList;
    }

    public void addCustomerObservableList(UserClass userClass) {
        customerObservableList.add(userClass);
    }

    public void storeCustomerObservableList(Context context) {
        try {
            String filename = "customer_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (customerObservableList != null && !customerObservableList.isEmpty()) {
                for (UserClass i : customerObservableList) {
                    String line = i.getCust_id() + "," + i.getCust_fname() + "," + i.getCust_lname() + "," + i.getCust_email() + "," + i.getCust_password();
                    writer.write(line);
                    writer.newLine();
                    Log.d("Writer", line);
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//    Customer-----------------------------------------------

//    Restaurant-----------------------------------------------
    ObservableArrayList<RestaurantClass> restaurantObservableList;

    public void loadRestaurantObservableList(Context context) {
        restaurantObservableList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "restaurant_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            Log.d("File Path", file.getAbsolutePath());
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] restaurant_data = input.split(",");
                String restaurant_id = restaurant_data[0];
                String restaurant_name = restaurant_data[1];
                String restaurant_shortDescription = restaurant_data[2];
                String restaurant_price = restaurant_data[3];
                String restaurant_description = restaurant_data[4];
                RestaurantClass restaurantClass = new RestaurantClass(restaurant_id, restaurant_name, restaurant_shortDescription, restaurant_price, restaurant_description);
                restaurantObservableList.add(restaurantClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storeRestaurantObservableList(Context context) {
        try {
            String filename = "restaurant_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (restaurantObservableList != null && !restaurantObservableList.isEmpty()) {
                for (RestaurantClass i : restaurantObservableList) {
                    String line = i.getRestaurant_id() + "," + i.getRestaurant_name() + "," + i.getRestaurant_shortDescription() + "," + i.getRestaurant_price_range() + "," + i.getRestaurant_Description();
                    writer.write(line);
                    writer.newLine();
                    Log.d("Writer", line);
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<RestaurantClass> getRestaurantObservableList() {
        return restaurantObservableList;
    }

    public void addRestaurantObservableList(RestaurantClass restaurantClass) {
        restaurantObservableList.add(restaurantClass);
    }
//    Restaurant-----------------------------------------------

//    Restaurant Food Item-----------------------------------------------
    ObservableArrayList<FoodItemsClass> foodItemsObservableArrayList;

    public void loadFoodItemObservableList(Context context) {
        foodItemsObservableArrayList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "menu_item_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] food_item_data = input.split(";");

                String food_item_id = food_item_data[0];
                String food_item_name = food_item_data[1];
                String food_item_description = food_item_data[2];
                String food_item_price = food_item_data[3];
                String food_availability = food_item_data[4];
                String food_category = food_item_data[5];
                String food_item_rest_id = food_item_data[6];

                FoodItemsClass foodItemsClass = new FoodItemsClass(food_item_id, food_item_name, food_item_description, food_item_price, food_availability, food_category, food_item_rest_id);
                foodItemsObservableArrayList.add(foodItemsClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storeFoodItemObservableList(Context context) {
        try {
            String filename = "menu_item_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (foodItemsObservableArrayList != null && !foodItemsObservableArrayList.isEmpty()) {
                for (FoodItemsClass i : foodItemsObservableArrayList) {
                    String line = i.getFoodItemId() + ";" + i.getFoodItemName() + ";" + i.getFoodItemDescription() + ";" + i.getFoodPrice() + ";" + i.getFood_availability() + ";" + i.getFood_category() + ";" + i.getFood_rest_id();
                    writer.write(line);
                    writer.newLine();
                    Log.d("Writer", line);
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<FoodItemsClass> getFoodItemsObservableArrayList() {
        return foodItemsObservableArrayList;
    }

    public void addFoodItemObservableList(FoodItemsClass foodItemsClass) {
        foodItemsObservableArrayList.add(foodItemsClass);
    }
//    Restaurant Food Item-----------------------------------------------

//    Reservation Data-----------------------------------------------
    ObservableArrayList<ReservationClass> reservationObservableArrayList;

    public void loadReservationObservableList(Context context) {
        reservationObservableArrayList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "reservation_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] reservation_data = input.split(";");
                String reservation_id = reservation_data[0];
                String cust_id = reservation_data[1];
                String reservation_name = reservation_data[2];
                String reservation_number_pax = reservation_data[3];
                String reservation_date = reservation_data[4];
                String reservation_time = reservation_data[5];
                String reservation_remarks = reservation_data[6];
                String reservation_rest_id = reservation_data[7];
                String reservation_approve = reservation_data[8];

                ReservationClass reservationClass = new ReservationClass(reservation_id, cust_id,reservation_name, reservation_number_pax,reservation_date, reservation_time, reservation_remarks, reservation_rest_id, reservation_approve);
                reservationObservableArrayList.add(reservationClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storeReservationObservableList(Context context) {
        try {
            String filename = "reservation_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (reservationObservableArrayList != null && !reservationObservableArrayList.isEmpty()) {
                for (ReservationClass i : reservationObservableArrayList) {
                    String line = i.getReserve_id() + ";" + i.getCust_id() + ";" + i.getReserve_name() + ";" + i.getNumber_pax() + ";" + i.getReserve_date() + ";" + i.getReserve_time() + ";" + i.getRemarks() + ";" + i.getReserve_rest_id() + ";" + i.getApprovement();
                    writer.write(line);
                    writer.newLine();
                    Log.d("Writer", line);
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<ReservationClass> getReservationObservableArrayList() {
        return reservationObservableArrayList;
    }

    public void addReservationObservableList(ReservationClass reservationClass) {
        reservationObservableArrayList.add(reservationClass);
    }
//    Reservation Data-----------------------------------------------

//    Order Status Data-----------------------------------------------
    ObservableArrayList<OrderStatusClass> orderStatusObservableArrayList;

    public void loadOrderStatusObservableArrayList(Context context) {
        orderStatusObservableArrayList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "order_status_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] order_status_data = input.split(";");
                String order_status_id = order_status_data[0];
                String order_status = order_status_data[1];

                OrderStatusClass orderStatusClass = new OrderStatusClass(order_status_id, order_status);
                orderStatusObservableArrayList.add(orderStatusClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storeOrderStatusObservableList(Context context) {
        try {
            String filename = "order_status_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (orderStatusObservableArrayList != null && !orderStatusObservableArrayList.isEmpty()) {
                for (OrderStatusClass i : orderStatusObservableArrayList) {
                    String line = i.getOrder_status_id() + ";" + i.getOrder_status();
                    writer.write(line);
                    writer.newLine();
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<OrderStatusClass> getOrderStatusObservableArrayList() {
        return orderStatusObservableArrayList;
    }

    public void addOrderStatusObservableArrayList(OrderStatusClass orderStatusClass) {
        orderStatusObservableArrayList.add(orderStatusClass);
    }
//    Order Status Data-----------------------------------------------

//    Order Class Data-----------------------------------------------
    ObservableArrayList<OrderClass> orderObservableArrayList;

    public void loadOrderObservableArrayList(Context context) {
        orderObservableArrayList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "order_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] order_data = input.split(";");
                String order_id = order_data[0];
                String order_date = order_data[1];
                String overall_total_price = order_data[2];
                String quantity = order_data[3];
                String sub_total_price = order_data[4];
                String rest_id = order_data[5];
                String cust_id = order_data[6];
                String order_status_id = order_data[7];
                String menu_item_id = order_data[8];

                OrderClass orderClass = new OrderClass(order_id, order_date, overall_total_price, quantity, sub_total_price, rest_id, cust_id, order_status_id, menu_item_id);
                orderObservableArrayList.add(orderClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storeOrderObservableList(Context context) {
        try {
            String filename = "order_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (orderObservableArrayList != null && !orderObservableArrayList.isEmpty()) {
                for (OrderClass i : orderObservableArrayList) {
                    String line = i.getOrder_id() + ";" + i.getOrder_date() + ";" + i.getOverall_total_price() + ";" + i.getQuantity() + ";" + i.getSub_total_price() + ";" + i.getRest_id() + ";" + i.getCust_id() + ";" + i.getOrder_status_id() + ";" + i.getMenu_item_id();
                    writer.write(line);
                    writer.newLine();
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<OrderClass> getOrderObservableArrayList() {
        return orderObservableArrayList;
    }

    public void addOrderObservableList(OrderClass orderClass) {
        orderObservableArrayList.add(orderClass);
    }
//    Order Class Data-----------------------------------------------

//    Payment Data-----------------------------------------------
    ObservableArrayList<PaymentClass> paymentObservableArrayList;

    public void loadPaymentObservableArrayList(Context context) {
        paymentObservableArrayList = new ObservableArrayList<>();
        try {
            File file = new File(context.getFilesDir(), "payment_t.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String input;

            while ((input = reader.readLine()) != null) {
                Log.d("data", input);
                String[] payment_data = input.split(";");
                String payment_id = payment_data[0];
                String amount = payment_data[1];
                String payment_date = payment_data[2];
                String cust_id = payment_data[3];
                String order_id = payment_data[4];

                PaymentClass paymentClass = new PaymentClass(payment_id, amount, payment_date, cust_id, order_id);
                paymentObservableArrayList.add(paymentClass);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void storePaymentObservableList(Context context) {
        try {
            String filename = "payment_t.txt";
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(filename, Context.MODE_PRIVATE));
            BufferedWriter writer = new BufferedWriter(outputStreamWriter);

            if (paymentObservableArrayList != null && !paymentObservableArrayList.isEmpty()) {
                for (PaymentClass i : paymentObservableArrayList) {
                    String line = i.getPayment_id() + ";" + i.getAmount() + ";" + i.getPayment_date() + ";" + i.getCust_id() + ";" + i.getOrder_id();
                    writer.write(line);
                    writer.newLine();
                }
            }
            writer.close();
            outputStreamWriter.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ObservableArrayList<PaymentClass> getPaymentObservableArrayList() {
        return paymentObservableArrayList;
    }

    public void addPaymentObservableList(PaymentClass paymentClass) {
        paymentObservableArrayList.add(paymentClass);
    }
//    Payment Data-----------------------------------------------
}








