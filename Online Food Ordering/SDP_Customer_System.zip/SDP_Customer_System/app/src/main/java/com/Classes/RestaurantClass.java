package com.Classes;

public class RestaurantClass {
    private String restaurant_id;

    private String restaurant_name;

    private String restaurant_shortDescription;

    private String restaurant_price_range;

    private String restaurant_Description;

    public RestaurantClass(String restaurant_id, String restaurant_name, String restaurant_shortDescription, String restaurant_price_range, String restaurant_Description) {
        this.restaurant_id = restaurant_id;
        this.restaurant_name = restaurant_name;
        this.restaurant_shortDescription = restaurant_shortDescription;
        this.restaurant_price_range = restaurant_price_range;
        this.restaurant_Description = restaurant_Description;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public String getRestaurant_name() {
        return restaurant_name;
    }

    public void setRestaurant_name(String restaurant_name) {
        this.restaurant_name = restaurant_name;
    }

    public String getRestaurant_shortDescription() {
        return restaurant_shortDescription;
    }

    public void setRestaurant_shortDescription(String restaurant_shortDescription) {
        this.restaurant_shortDescription = restaurant_shortDescription;
    }

    public String getRestaurant_price_range() {
        return restaurant_price_range;
    }

    public void setRestaurant_price_range(String restaurant_price_range) {
        this.restaurant_price_range = restaurant_price_range;
    }

    public String getRestaurant_Description() {
        return restaurant_Description;
    }

    public void setRestaurant_Description(String restaurant_Description) {
        this.restaurant_Description = restaurant_Description;
    }
}
