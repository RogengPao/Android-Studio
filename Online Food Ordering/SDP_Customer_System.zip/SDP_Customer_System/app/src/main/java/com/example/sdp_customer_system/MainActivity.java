package com.example.sdp_customer_system;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.Classes.DataConverter;
import com.Classes.FoodItemsClass;
import com.Classes.OrderStatusClass;
import com.Classes.RestaurantClass;

public class MainActivity extends AppCompatActivity {
    private static final long DELAY_TIME = 3000;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_page);
        new Handler().postDelayed(() -> {
            DataConverter.getInstance().loadCustomerObservableList(getApplicationContext());
            DataConverter.getInstance().loadRestaurantObservableList(getApplicationContext());
            DataConverter.getInstance().loadFoodItemObservableList(getApplicationContext());
            DataConverter.getInstance().loadReservationObservableList(getApplicationContext());
            DataConverter.getInstance().loadOrderStatusObservableArrayList(getApplicationContext());
            DataConverter.getInstance().loadOrderObservableArrayList(getApplicationContext());
            DataConverter.getInstance().loadPaymentObservableArrayList(getApplicationContext());


            Intent intent = new Intent(MainActivity.this, LogInActivity.class);
            startActivity(intent);

            // Finish the first activity
            finish();
        }, DELAY_TIME);
    }
}

