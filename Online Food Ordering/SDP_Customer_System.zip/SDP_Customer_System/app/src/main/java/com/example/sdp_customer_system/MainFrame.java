package com.example.sdp_customer_system;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.databinding.ObservableArrayList;
import androidx.drawerlayout.widget.DrawerLayout;

import com.Classes.DataConverter;
import com.Classes.FoodItemsClass;
import com.Classes.OrderClass;
import com.Classes.OrderStatusClass;
import com.Classes.PaymentClass;
import com.Classes.ReservationClass;
import com.Classes.RestaurantClass;
import com.Classes.SessionManager;
import com.Classes.UserClass;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.mysql.cj.x.protobuf.MysqlxCrud;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ListIterator;

public class MainFrame extends AppCompatActivity {
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_frame);

        drawerLayout = findViewById(R.id.drawerLayout);
        Button openSidebarButton = findViewById(R.id.openSidebarButton);

        TextView username = findViewById(R.id.navigationBarUserID);
        TextView user_gmail = findViewById(R.id.navigationBarUserGmail);

        username.setText((String) SessionManager.getInstance().get("cust_username"));
        user_gmail.setText((String) SessionManager.getInstance().get("cust_email"));

        openSidebarButton.setOnClickListener(v -> openSidebar());
        initialize();
    }



//    Initial Progress and Functions------------------------------------------------------------
    public void initialize() {
        LinearLayout container = findViewById(R.id.homePageCardViewContainer);
        container.removeAllViews();

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            View cardView = getLayoutInflater().inflate(R.layout.card_vew_restaurant, null);

            int cardHeight = 300;
            cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cardHeight));

            int marginLeft = 1;
            int marginTop = 3;
            int marginRight = 1;
            int marginBottom = 3;
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
            layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

            Button buttonRO = cardView.findViewById(R.id.buttonToRO);
            String restaurantId = i.getRestaurant_id();
            buttonRO.setId(Integer.parseInt(restaurantId));

            TextView restaurant_name = cardView.findViewById(R.id.menuItemName);
            TextView restaurant_shortDescription = cardView.findViewById(R.id.menuItemDescription);
            TextView restaurant_price = cardView.findViewById(R.id.restaurantPriceRangeCard);

            restaurant_name.setText(i.getRestaurant_name());
            restaurant_shortDescription.setText(i.getRestaurant_shortDescription());
            restaurant_price.setText(i.getRestaurant_price_range());

            container.addView(cardView);
        }
    }
    public void openSidebar() {
        drawerLayout.openDrawer(GravityCompat.START);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



//Side Bar Navigation Codes//------------------------------------------------------------
    public void homePage(View view) {
        Button button = findViewById(R.id.home_page);
        String buttonID = getResources().getResourceEntryName(button.getId());
        switchPage(buttonID);
        initialize();
    }
    public void orderStatusPage(View view) {
        Button button = findViewById(R.id.check_order_page);
        String buttonID = getResources().getResourceEntryName(button.getId());
        switchPage(buttonID);
        setupOrderStatusPage();
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void Dashboard(View view) {
        Button button = findViewById(R.id.dashboard_page);
        String buttonID = getResources().getResourceEntryName(button.getId());
        switchPage(buttonID);
        setupDashboard();
    }
    public void profilePage(View view) {
        Button button = findViewById(R.id.profile_page);
        String buttonID = getResources().getResourceEntryName(button.getId());
        switchPage(buttonID);
        setupProfile();
    }
    public void bookingPage(View view) {
        Button button = findViewById(R.id.reservation_booking);
        String buttonID = getResources().getResourceEntryName(button.getId());
        switchPage(buttonID);
        setupBookingReservationDetail();
    }
    public void switchPage(String filename) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier(filename, "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);
    }
    public void logOutNow(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Log Out");
        builder.setMessage("Are you sure you want to log out?");
        builder.setPositiveButton("OK", (dialog, which) -> {
            dialog.dismiss();
            Intent intent = new Intent(MainFrame.this, LogInActivity.class);
            startActivity(intent);
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        SessionManager.getInstance().clear();
    }



//Navigate and Setup to Restaurant Overview//------------------------------------------------------------
    public void headToRO(View view) {
        int buttonId = view.getId();
        Log.d("ID ID ID", String.valueOf(buttonId));
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(R.layout.restaurant_overview_page , pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            if (i.getRestaurant_id().equals(String.valueOf(buttonId))) {
                setupRO(i.getRestaurant_name(), i.getRestaurant_price_range(), i.getRestaurant_Description(), i.getRestaurant_id());
            }
        }
    }

    public void setupRO(String name, String range, String desc, String restaurant_id) {
        TextView textView = findViewById(R.id.restaurantName);
        textView.setText(name);
        TextView textView1 = findViewById(R.id.price_range);
        textView1.setText(range);
        TextView textView2 = findViewById(R.id.short_description);
        textView2.setText(desc);

        Button reservationButton = findViewById(R.id.reservation_page);
        reservationButton.setId(Integer.parseInt(restaurant_id));

        Button orderFoodPage = findViewById(R.id.order_food_page);
        orderFoodPage.setId(Integer.parseInt(restaurant_id));

        LinearLayout container = findViewById(R.id.food_item_card_view);
        container.removeAllViews();

        for (FoodItemsClass i : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
            if (i.getFood_rest_id().equals(restaurant_id)) {
                View cardView = getLayoutInflater().inflate(R.layout.menu_item_cardview, null);

                int cardHeight = 300;
                cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cardHeight));

                int marginLeft = 0;
                int marginTop = 0;
                int marginRight = 0;
                int marginBottom = 15;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                TextView food_id = cardView.findViewById(R.id.menuItemCodeCard);
                TextView food_name = cardView.findViewById(R.id.menuItemName);
                TextView food_description = cardView.findViewById(R.id.menuItemDescription);
                TextView food_price = cardView.findViewById(R.id.foodPriceCard);

                ImageView food_image = cardView.findViewById(R.id.foodItemView);
                String food_image_name = "fooditem" + i.getFoodItemId();

                try {
                    int resourceId = getResources().getIdentifier(food_image_name, "drawable", getPackageName());
                    food_image.setImageResource(resourceId);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                String foodItemCode = "Item code: #" + i.getFoodItemId();
                food_id.setText(foodItemCode);
                food_name.setText(i.getFoodItemName());
                food_description.setText(i.getFoodItemDescription());
                food_price.setText(i.getFoodPrice());

                container.addView(cardView);
            }
        }
    }


//Navigate and Setup Book Reservation//------------------------------------------------------------
    public void reservationPage(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("reservation_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button backToRO2 = findViewById(R.id.backToRO2);


        setupRForm();

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            if (i.getRestaurant_id().equals(String.valueOf(view.getId()))) {
                TextView reservation_rest = findViewById(R.id.reservationRestaurantName);
                reservation_rest.setText(i.getRestaurant_name());
                backToRO2.setId(Integer.parseInt(i.getRestaurant_id()));
            }
        }
    }

    public void setupRForm() {
        EditText reservationName = findViewById(R.id.reservationName);
        reservationName.setText(SessionManager.getInstance().get("cust_username").toString());

        Spinner spinner1 = findViewById(R.id.spinner1);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.number_of_pax, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);


        Button datepicker = findViewById(R.id.reserveCalendar);

        datepicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalendarDialog();
            }
        });

        Button timepicker = findViewById(R.id.timeDialogButton);

        timepicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTimeDialog();
            }
        });
    }

    private void openCalendarDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                EditText dateString = findViewById(R.id.reserveCalendarField);
                dateString.setText(String.valueOf(year)+"/"+String.valueOf(month)+"/"+String.valueOf(dayOfMonth));
            }
        }, year, month, dayOfMonth);

        dialog.show();
    }

    private void openTimeDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                EditText timeString = findViewById(R.id.reserveTimeText);
                String formattedMinute = String.format("%02d", minute);
                timeString.setText(hourOfDay + ":" + formattedMinute);
            }
        }, hour, minute, true);

        timePickerDialog.show();
    }

    public void requestBooking(View view) {
        boolean validated = true;
        TextView restaurantName = findViewById(R.id.reservationRestaurantName);
        EditText reservationName = findViewById(R.id.reservationName);
        EditText reservationDate = findViewById(R.id.reserveCalendarField);
        EditText reservationTime = findViewById(R.id.reserveTimeText);
        EditText reservationRemarks = findViewById(R.id.reservation_remarks);
        Spinner pax_spinner = findViewById(R.id.spinner1);
        

        if (reservationName.getText().toString().isEmpty()) {
            reservationName.setError("First Name is Required");
            validated = false;
        } else if (!(reservationName.getText().toString().length() >= 4 && reservationName.getText().toString().length() <= 12)) {
            validated = false;
            reservationName.setTextColor(Color.RED);
            reservationName.setError("First Name should be between 5-12 letters");
        } else {
            reservationName.setTextColor(Color.rgb(102, 153, 51));
        }

        if (reservationDate.getText().toString().isEmpty()) {
            reservationDate.setError("Please select a date");
            validated = false;
        } else {
            reservationDate.setTextColor(Color.rgb(102, 153, 51));
        }

        if (reservationTime.getText().toString().isEmpty()) {
            reservationTime.setError("Please select a date");
            validated = false;
        }  else {
            reservationTime.setTextColor(Color.rgb(102, 153, 51));
        }

        if (validated) {
            Log.d("Add Reservation", "Success");
            String rest_id = null;
            for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
                if (i.getRestaurant_name().equals(restaurantName.getText().toString())) {
                    rest_id = i.getRestaurant_id();
                    break;
                }
            }
            if (reservationRemarks.getText().toString().isEmpty() || reservationRemarks.getText() == null) {
                ReservationClass reservationClass = new ReservationClass(String.valueOf(DataConverter.getInstance().getReservationObservableArrayList().size() +1 ), SessionManager.getInstance().get("cust_id").toString(), reservationName.getText().toString(), pax_spinner.getSelectedItem().toString(), reservationDate.getText().toString(), reservationTime.getText().toString(), rest_id, "Not Approved");
                DataConverter.getInstance().getReservationObservableArrayList().add(reservationClass);
            } else {
                ReservationClass reservationClass = new ReservationClass(String.valueOf(DataConverter.getInstance().getReservationObservableArrayList().size() +1 ), SessionManager.getInstance().get("cust_id").toString(),reservationName.getText().toString(), pax_spinner.getSelectedItem().toString(), reservationDate.getText().toString(), reservationTime.getText().toString(), reservationRemarks.getText().toString(), rest_id, "Approved");
                DataConverter.getInstance().getReservationObservableArrayList().add(reservationClass);
            }
            DataConverter.getInstance().storeReservationObservableList(getApplicationContext());
            Toast.makeText(getApplicationContext(), "Requested Booking", Toast.LENGTH_SHORT).show();
        }
    }



//Setup and Edit Profile Page Codes//------------------------------------------------------------
    private void setupProfile() {
        TextView userProfile = findViewById(R.id.profileName);
        userProfile.setText((String) SessionManager.getInstance().get("cust_username"));

        EditText cust_id = findViewById(R.id.cust_ID_textfield);
        cust_id.setText( (String) SessionManager.getInstance().get("cust_id"));

        EditText cust_fname = findViewById(R.id.firstNameTextField);
        cust_fname.setText( (String) ((String) SessionManager.getInstance().get("cust_username")).split(" ")[0]);

        EditText cust_lname = findViewById(R.id.lastNameTextfield);
        cust_lname.setText( (String) ((String) SessionManager.getInstance().get("cust_username")).split(" ")[1]);

        EditText cust_email = findViewById(R.id.emailTextfield);
        cust_email.setText( (String) SessionManager.getInstance().get("cust_email"));

        EditText cust_passowrd = findViewById(R.id.passwordTextField);
        cust_passowrd.setText((String) SessionManager.getInstance().get("cust_password"));
    }

    public void editProfile(View view) {
        EditText cust_fname = findViewById(R.id.firstNameTextField);
        EditText cust_lname = findViewById(R.id.lastNameTextfield);
        EditText cust_email = findViewById(R.id.emailTextfield);
        EditText cust_passowrd = findViewById(R.id.passwordTextField);

        EditText[] cust_data = new EditText[] {cust_fname, cust_lname, cust_email, cust_passowrd};
        for (EditText i : cust_data) {
            i.setEnabled(true);
        }
        Button confirm = findViewById(R.id.confirmEditProfile);
        confirm.setEnabled(true);
    }

    public void confirmEdit(View view) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.edit_profile_confirmation, null);
        final EditText editTextPassword = dialogView.findViewById(R.id.editTextPassword);


        // Create an AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter password for confirmation")
                .setView(dialogView)
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (editTextPassword.getText().toString().equals(SessionManager.getInstance().get("cust_password"))) {
                            Toast.makeText(getApplicationContext(), "Edit Success!", Toast.LENGTH_SHORT).show();
                            confirmEditProcess();
                        } else {
                            Toast.makeText(getApplicationContext(), "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        EditText cust_fname = findViewById(R.id.firstNameTextField);
                        EditText cust_lname = findViewById(R.id.lastNameTextfield);
                        EditText cust_email = findViewById(R.id.emailTextfield);
                        EditText cust_passowrd = findViewById(R.id.passwordTextField);

                        EditText[] cust_data = new EditText[] {cust_fname, cust_lname, cust_email, cust_passowrd};
                        for (EditText x: cust_data) {
                            x.setEnabled(false);
                        }
                        Button confirm = findViewById(R.id.confirmEditProfile);
                        confirm.setEnabled(false);

                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void confirmEditProcess() {
        EditText cust_id = findViewById(R.id.cust_ID_textfield);
        EditText cust_fname = findViewById(R.id.firstNameTextField);
        EditText cust_lname = findViewById(R.id.lastNameTextfield);
        EditText cust_email = findViewById(R.id.emailTextfield);
        EditText cust_passowrd = findViewById(R.id.passwordTextField);

        for (UserClass i : DataConverter.getInstance().getCustomerObservableList()) {
            if (i.getCust_id().equals(cust_id.getText().toString())) {
                i.setCust_fname(cust_fname.getText().toString());
                i.setCust_lname(cust_lname.getText().toString());
                i.setCust_email(cust_email.getText().toString());
                i.setCust_password(cust_passowrd.getText().toString());

                DataConverter.getInstance().storeCustomerObservableList(getApplicationContext());

                SessionManager.getInstance().clear();
                SessionManager sessionManager = SessionManager.getInstance();
                sessionManager.set("cust_id", i.getCust_id());
                sessionManager.set("cust_username", i.getCust_fname() + " " + i.getCust_lname());
                    sessionManager.set("cust_email", i.getCust_email());
                sessionManager.set("cust_password", i.getCust_password());

                TextView username = findViewById(R.id.navigationBarUserID);
                TextView user_gmail = findViewById(R.id.navigationBarUserGmail);

                username.setText((String) SessionManager.getInstance().get("cust_username"));
                user_gmail.setText((String) SessionManager.getInstance().get("cust_email"));

                TextView userProfile = findViewById(R.id.profileName);
                userProfile.setText((String) SessionManager.getInstance().get("cust_username"));

                EditText[] cust_data = new EditText[] {cust_fname, cust_lname, cust_email, cust_passowrd};
                for (EditText x: cust_data) {
                    x.setEnabled(false);
                }
                Button confirm = findViewById(R.id.confirmEditProfile);
                confirm.setEnabled(false);
            }
        }
    }


//Setup Booking reservation Page Codes//------------------------------------------------------------
    public void setupBookingReservationDetail(){
        LinearLayout container = findViewById(R.id.reservationBookingContainer);
        container.removeAllViews();
        for (ReservationClass i : DataConverter.getInstance().getReservationObservableArrayList()) {
            if (i.getCust_id().equals(SessionManager.getInstance().get("cust_id"))) {
                View cardView = getLayoutInflater().inflate(R.layout.reservation_booking_cards, null);

                cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                int marginLeft = 5;
                int marginTop = 0;
                int marginRight = 5;
                int marginBottom = 25;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                String restaurant = null;
                for (RestaurantClass x : DataConverter.getInstance().getRestaurantObservableList()) {
                    if (x.getRestaurant_id().equals(i.getReserve_rest_id())) {
                        restaurant = x.getRestaurant_name();
                    }
                }

                TextView restaurantname = cardView.findViewById(R.id.bookingCardName);
                TextView reservationDate = cardView.findViewById(R.id.bookingDateCard);
                TextView reservationPax = cardView.findViewById(R.id.reservationPax);
                TextView reservationTime = cardView.findViewById(R.id.bookingReservationTime);
                TextView reservationApproval = cardView.findViewById(R.id.reservationApproval);
                ImageView reservationRestImage = cardView.findViewById(R.id.reservationBookingImage);

                String restaurant_image_background = "reservation" + i.getReserve_rest_id();

                try {
                    int resourceId = getResources().getIdentifier(restaurant_image_background, "drawable", getPackageName());
                    reservationRestImage.setImageResource(resourceId);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                restaurantname.setText(restaurant);
                reservationDate.setText("Date: " + i.getReserve_date());
                reservationPax.setText("Number of Pax: " + i.getNumber_pax());
                reservationTime.setText("Time: " + i.getReserve_time());
                reservationApproval.setText(i.getApprovement());

                if (reservationApproval.getText().toString().equals("Not Approved")) {
                    reservationApproval.setTextColor(Color.RED);
                } else {
                    reservationApproval.setTextColor(Color.rgb(102, 153, 51));
                }
                container.addView(cardView);
            }
        }
    }


//Setup Order Page Codes//------------------------------------------------------------
    ObservableArrayList<String> cartObservableList = new ObservableArrayList<>();

    public void orderNow(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("order_food_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button cartButton = findViewById(R.id.cartButton);
        cartButton.setText("Cart (" + cartObservableList.size() + ")");
        cartButton.setId(view.getId());

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            if (i.getRestaurant_id().equals(String.valueOf(view.getId()))) {
                Button backToRO = findViewById(R.id.backToRO);
                backToRO.setId(Integer.parseInt(i.getRestaurant_id()));

                TextView restaurantName = findViewById(R.id.orderNowRestaurantName);
                restaurantName.setText(i.getRestaurant_name());
                TextView restaurantDesc = findViewById(R.id.orderNowFoodDesc);
                restaurantDesc.setText(i.getRestaurant_shortDescription());

                setupOrderNow(i.getRestaurant_id());
            }
        }
    }

    public void setupOrderNow(String restaurant_id) {
        LinearLayout container = findViewById(R.id.mainDishContainer);
        container.removeAllViews();
        LinearLayout container2 = findViewById(R.id.drinksContainer);
        container2.removeAllViews();

        for (FoodItemsClass i : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
            if (i.getFood_rest_id().equals(restaurant_id)) {
                View cardView = getLayoutInflater().inflate(R.layout.order_now_food_card, null);

                cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                int marginLeft = 15;
                int marginTop = 0;
                int marginRight = 15;
                int marginBottom = 0;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                TextView food_id = cardView.findViewById(R.id.orderNowCardFoodName);
                TextView food_price = cardView.findViewById(R.id.orderNowFoodPriceCard);
                food_id.setText(i.getFoodItemName());
                food_price.setText(i.getFoodPrice());

                ImageView food_image = cardView.findViewById(R.id.orderNowFoodImage);
                String food_image_name = "fooditem" + i.getFoodItemId();

                Button orderFoodCardButton = cardView.findViewById(R.id.orderFoodCardButton);
                orderFoodCardButton.setId(Integer.parseInt(i.getFoodItemId()));

                try {
                    int resourceId = getResources().getIdentifier(food_image_name, "drawable", getPackageName());
                    food_image.setImageResource(resourceId);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (i.getFood_category().equals("Main Dish")) {
                    container.addView(cardView);
                } else if (i.getFood_category().equals("Drink")) {
                    container2.addView(cardView);
                }

            }
        }
    }


//Display Food Page Codes//------------------------------------------------------------
    public void headToDisplayFood(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("display_food_item_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button backToOrderNow = findViewById(R.id.backToOrderNow);


        TextView displayFoodName = findViewById(R.id.displayFoodName);
        TextView displayFoodDesc = findViewById(R.id.displayFoodDesc);
        TextView displayFoodPrice = findViewById(R.id.displayFoodPrice);

        Button addToCartButton = findViewById(R.id.addToCartButton);
        addToCartButton.setId(view.getId());

        String food_id = String.valueOf(view.getId());

        for (FoodItemsClass i : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
            if (food_id.equals(i.getFoodItemId())) {
                displayFoodName.setText(i.getFoodItemName());
                displayFoodDesc.setText(i.getFoodItemDescription());
                displayFoodPrice.setText(i.getFoodPrice());
                backToOrderNow.setId(Integer.parseInt(i.getFood_rest_id()));
                ImageView displayFoodImage = findViewById(R.id.displayFoodImage);
                String food_image_name = "fooditem" + i.getFoodItemId();

                try {
                    int resourceId = getResources().getIdentifier(food_image_name, "drawable", getPackageName());
                    displayFoodImage.setImageResource(resourceId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void minusAmount(View view) {
        TextView displayFoodAmount = findViewById(R.id.displayFoodAmount);
        int amount = Integer.parseInt(String.valueOf(displayFoodAmount.getText()));
        if (Integer.parseInt(String.valueOf(displayFoodAmount.getText())) > 1) {
            amount -= 1;
            displayFoodAmount.setText(String.valueOf(amount));
        } else {
            Toast.makeText(getApplicationContext(), "Min Amount Reached", Toast.LENGTH_SHORT).show();
        }
    }

    public void addAmount(View view) {
        TextView displayFoodAmount = findViewById(R.id.displayFoodAmount);
        int amount = Integer.parseInt(String.valueOf(displayFoodAmount.getText()));
        if (Integer.parseInt(String.valueOf(displayFoodAmount.getText())) < 10) {
            amount += 1;
            displayFoodAmount.setText(String.valueOf(amount));
        } else {
            Toast.makeText(getApplicationContext(), "Max Amount Reached", Toast.LENGTH_SHORT).show();
        }
    }

    public void addFoodItemToCart(View view) {
        TextView displayFoodAmount = findViewById(R.id.displayFoodAmount);

        List<String> itemsToAdd = new ArrayList<>();
        ListIterator<String> iterator = cartObservableList.listIterator();

        boolean found = false;
        while (iterator.hasNext()) {
            String item = iterator.next();
            if (item.split(";")[0].equals(String.valueOf(view.getId()))) {
                String food_id = item.split(";")[0];
                int number = Integer.parseInt(item.split(";")[1]);
                number += 1;
                iterator.set(food_id + ";" + number);
                found = true;
            }
        }

        if (!found) {
            itemsToAdd.add(view.getId() + ";" + displayFoodAmount.getText().toString());
        }

        cartObservableList.addAll(itemsToAdd);

        Toast.makeText(getApplicationContext(), "Food Added to Cart", Toast.LENGTH_SHORT).show();
    }


//Navigate Stall Page Codes//------------------------------------------------------------
    public void backToRO(View view) {
        int buttonId = view.getId();
        Log.d("ID ID ID", String.valueOf(buttonId));
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(R.layout.restaurant_overview_page , pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            if (i.getRestaurant_id().equals(String.valueOf(buttonId))) {
                setupRO(i.getRestaurant_name(), i.getRestaurant_price_range(), i.getRestaurant_Description(), i.getRestaurant_id());
            }
        }
    }

    public void backToOrder(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("order_food_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button cartButton = findViewById(R.id.cartButton);
        cartButton.setText("Cart (" + cartObservableList.size() + ")");
        cartButton.setId(view.getId());

        for (RestaurantClass i : DataConverter.getInstance().getRestaurantObservableList()) {
            if (i.getRestaurant_id().equals(String.valueOf(view.getId()))) {
                Button backToRO = findViewById(R.id.backToRO);
                backToRO.setId(Integer.parseInt(i.getRestaurant_id()));

                TextView restaurantName = findViewById(R.id.orderNowRestaurantName);
                restaurantName.setText(i.getRestaurant_name());
                TextView restaurantDesc = findViewById(R.id.orderNowFoodDesc);
                restaurantDesc.setText(i.getRestaurant_shortDescription());

                setupOrderNow(i.getRestaurant_id());
            }
        }
    }


//Cart Page Codes//------------------------------------------------------------
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void headToCartPage(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("cart_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button backToOrderNow3 = findViewById(R.id.backToOrderNow3);
        backToOrderNow3.setId(view.getId());

        Button checkOutButton = findViewById(R.id.checkOutButton);
        checkOutButton.setId(view.getId());

        TextView cart_food_date_card = findViewById(R.id.cart_food_date_card);
        cart_food_date_card.setText(String.valueOf(LocalDate.now()));

        setupCart();
    }

    public void setupCart() {
        LinearLayout container = findViewById(R.id.cartViewContainer);
        container.removeAllViews();
        Double grandTotalPrice = 0.00;
        for (String x : cartObservableList) {
            String food_id = x.split(";")[0];
            String food_number = x.split(";")[1];
            for (FoodItemsClass i : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
                if (i.getFoodItemId().equals(food_id)) {
                    View cardView = getLayoutInflater().inflate(R.layout.food_cart_card, null);
                    cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                    int marginLeft = 0;
                    int marginTop = 0;
                    int marginRight = 0;
                    int marginBottom = 15;
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                    layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                    Button deleteItemButton = cardView.findViewById(R.id.deleteItemButton);
                    deleteItemButton.setId(Integer.parseInt(food_id));

                    Button addFoodItemByOne = cardView.findViewById(R.id.addFoodItemByOne);
                    addFoodItemByOne.setId(Integer.parseInt(food_id));

                    Button minusFoodItemByOne = cardView.findViewById(R.id.minusFoodItemByOne);
                    minusFoodItemByOne.setId(Integer.parseInt(food_id));


                    TextView cart_food_name_card = cardView.findViewById(R.id.checkOutCardName);
                    cart_food_name_card.setText(i.getFoodItemName());

                    TextView cart_food_amount_card = cardView.findViewById(R.id.cart_food_amount_card);
                    cart_food_amount_card.setText(food_number);

                    TextView cart_food_price_card = cardView.findViewById(R.id.checkOutPriceCard);

                    double total_price = Double.parseDouble(food_number) * Double.parseDouble(i.getFoodPrice());

                    String formattedTotalPrice = String.format("%.2f", total_price);
                    double roundedTotalPrice = Double.parseDouble(formattedTotalPrice);
                    grandTotalPrice += roundedTotalPrice;
                    cart_food_price_card.setText(String.valueOf(roundedTotalPrice));

                    ImageView cart_food_image_card = cardView.findViewById(R.id.checkOutFoodCardImage);
                    String food_image_name = "fooditem" + i.getFoodItemId();

                    try {
                        int resourceId = getResources().getIdentifier(food_image_name, "drawable", getPackageName());
                        cart_food_image_card.setImageResource(resourceId);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    container.addView(cardView);
                    break;
                }
            }
        }

        TextView grandTotalPriceText = findViewById(R.id.grandTotalPrice);
        if (grandTotalPrice == 0.0) {
            grandTotalPriceText.setText("0.00");
        } else {
            String formattedTotalPrice = String.format("%.2f", grandTotalPrice);
            double roundedTotalPrice = Double.parseDouble(formattedTotalPrice);
            grandTotalPriceText.setText(String.valueOf(roundedTotalPrice));
        }
    }

    public void deleteCart(View view) {
        cartObservableList.clear();

        LinearLayout container = findViewById(R.id.cartViewContainer);
        container.removeAllViews();

        Toast.makeText(getApplicationContext(), "Cleared Cart", Toast.LENGTH_SHORT).show();

        TextView grandTotalPriceText = findViewById(R.id.grandTotalPrice);
        grandTotalPriceText.setText("0.00");
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void deleteItem(View view) {
        for (String i : cartObservableList) {
            if (i.split(";")[0].equals(String.valueOf(view.getId()))) {
                cartObservableList.remove(i);
                break;
            }
        }
        setupCart();
    }

    public void deleteFoodItemByOne(View view) {
        for (int index = 0; index < cartObservableList.size(); index++) {
            String item = cartObservableList.get(index);
            if (item.split(";")[0].equals(String.valueOf(view.getId()))) {
                int initialFoodAmount = Integer.parseInt(item.split(";")[1]);
                initialFoodAmount -= 1;
                if (initialFoodAmount > 0) {
                    String updatedItem = item.split(";")[0] + ";" + initialFoodAmount;
                    cartObservableList.set(index, updatedItem);
                } else {
                    // Remove item from the list if the quantity becomes zero
                    cartObservableList.remove(index);
                }
                break; // Stop iterating after finding and updating the item
            }
        }
        setupCart();
    }

    public void addFoodItemByOne(View view) {
        for (int index = 0; index < cartObservableList.size(); index++) {
            String item = cartObservableList.get(index);
            if (item.split(";")[0].equals(String.valueOf(view.getId()))) {
                int initialFoodAmount = Integer.parseInt(item.split(";")[1]);
                initialFoodAmount += 1;
                String updatedItem = item.split(";")[0] + ";" + initialFoodAmount;
                cartObservableList.set(index, updatedItem);
                break; // Stop iterating after finding and updating the item
            }
        }
        setupCart();
    }

    public void checkOut(View view) {
        TextView grandTotalPriceText = findViewById(R.id.grandTotalPrice);
        String checkOutPrice = grandTotalPriceText.getText().toString();

        if (grandTotalPriceText.getText().toString().equals("0.00")) {
            Toast.makeText(getApplicationContext(), "Can't Check Out with 0 items in Cart", Toast.LENGTH_SHORT).show();
        } else {
            LinearLayout pageContainer = findViewById(R.id.containerPage);
            LayoutInflater inflater = LayoutInflater.from(this);
            @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("check_out_page", "layout", getPackageName()), pageContainer, false);
            pageContainer.removeAllViews();
            pageContainer.addView(page);

            Button headBackToCart = findViewById(R.id.headBackToCart);
            headBackToCart.setId(view.getId());

            TextView totalItemCheckOut = findViewById(R.id.totalItemCheckOut);
            totalItemCheckOut.setText(cartObservableList.size() + " items");

            TextView totalPriceCheckOut = findViewById(R.id.totalPriceCheckOut);
            totalPriceCheckOut.setText(checkOutPrice);

            LinearLayout container = findViewById(R.id.checkOutContainer);

            for (String x : cartObservableList) {
                for (FoodItemsClass i : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
                    if (i.getFoodItemId().equals(x.split(";")[0])) {
                        View cardView = getLayoutInflater().inflate(R.layout.check_out_cards, null);

                        cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                        int marginLeft = 0;
                        int marginTop = 0;
                        int marginRight = 0;
                        int marginBottom = 15;
                        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                        layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                        TextView checkOutCardName = cardView.findViewById(R.id.checkOutCardName);
                        checkOutCardName.setText(i.getFoodItemName());

                        TextView checkOutAmount = cardView.findViewById(R.id.checkOutAmount);
                        checkOutAmount.setText("Amount: " + x.split(";")[1]);

                        ImageView checkOutFoodCardImage = cardView.findViewById(R.id.checkOutFoodCardImage);
                        String food_image_name = "fooditem" + i.getFoodItemId();

                        TextView checkOutPriceCard = cardView.findViewById(R.id.checkOutPriceCard);
                        double itemPrice = Double.parseDouble(i.getFoodPrice()) * Double.parseDouble(x.split(";")[1]);

                        double roundedTotalPrice = Math.round(itemPrice * 100.0) / 100.0;
                        String formattedTotalPrice = String.format("%.2f", roundedTotalPrice);

                        checkOutPriceCard.setText(formattedTotalPrice);

                        try {
                            int resourceId = getResources().getIdentifier(food_image_name, "drawable", getPackageName());
                            checkOutFoodCardImage.setImageResource(resourceId);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        container.addView(cardView);
                    }
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void backToCart(View view) {
        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("cart_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        Button backToOrderNow3 = findViewById(R.id.backToOrderNow3);
        backToOrderNow3.setId(view.getId());

        TextView cart_food_date_card = findViewById(R.id.cart_food_date_card);
        cart_food_date_card.setText(String.valueOf(LocalDate.now()));

        setupCart();
    }

//Cart Page Codes//------------------------------------------------------------
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void payNow(View view) {
        Toast.makeText(getApplicationContext(), "Payment Successful", Toast.LENGTH_SHORT).show();

        String previousOrderId = null;
        int counter = 0;

        for (OrderClass order : DataConverter.getInstance().getOrderObservableArrayList()) {
            String currentOrderId = order.getOrder_id();
            if (previousOrderId == null || !currentOrderId.equals(previousOrderId)) {
                counter++;
            }
            previousOrderId = currentOrderId;
        }
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);

        TextView totalPriceCheckOut = findViewById(R.id.totalPriceCheckOut);


        double sub_price = 0.0;
        String rest_id = null;
        String menuItemID = null;
        for (String i : cartObservableList) {
            for (FoodItemsClass x : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
                if (i.split(";")[0].equals(x.getFoodItemId())) {
                    sub_price = Double.parseDouble(x.getFoodPrice());
                    rest_id = x.getFood_rest_id();
                    menuItemID = x.getFoodItemId();
                    break;
                }
            }
            Double total_sub_price = sub_price * Double.parseDouble(i.split(";")[1]);
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            total_sub_price = Double.parseDouble(decimalFormat.format(total_sub_price));

            OrderClass orderClass = new OrderClass(String.valueOf(counter), formattedDateTime, totalPriceCheckOut.getText().toString(), i.split(";")[1], String.valueOf(total_sub_price),  rest_id, String.valueOf(SessionManager.getInstance().get("cust_id")), "1",  menuItemID);
            DataConverter.getInstance().addOrderObservableList(orderClass);
            DataConverter.getInstance().storeOrderObservableList(getApplicationContext());
        }

        PaymentClass paymentClass = new PaymentClass(String.valueOf(DataConverter.getInstance().getPaymentObservableArrayList().size()), totalPriceCheckOut.getText().toString(), String.valueOf(LocalDate.now()), String.valueOf(SessionManager.getInstance().get("cust_id")), String.valueOf(counter));
        DataConverter.getInstance().addPaymentObservableList(paymentClass);
        DataConverter.getInstance().storePaymentObservableList(getApplicationContext());

        LinearLayout pageContainer = findViewById(R.id.containerPage);
        LayoutInflater inflater = LayoutInflater.from(this);
        @SuppressLint("DiscouragedApi") View page = inflater.inflate(getResources().getIdentifier("home_page", "layout", getPackageName()), pageContainer, false);
        pageContainer.removeAllViews();
        pageContainer.addView(page);

        cartObservableList.clear();
    }


//Order Status Page Codes//------------------------------------------------------------
    public void setupOrderStatusPage() {
        LinearLayout container = findViewById(R.id.orderStatusContainer);
        container.removeAllViews();

        List<String> IDList = new ArrayList<>();

        for (OrderClass i : DataConverter.getInstance().getOrderObservableArrayList()) {
            String orderID = i.getOrder_id();
            String orderStatusID = i.getOrder_status_id();
            String orderInfo = orderID + ";" + orderStatusID;

            if (!IDList.contains(orderInfo)) {
                IDList.add(orderInfo);
            }
        }

        for (String i : IDList) {
            StringBuilder foodList = new StringBuilder();
            for (OrderClass x : DataConverter.getInstance().getOrderObservableArrayList()) {
                if (i.split(";")[0].equals(x.getOrder_id())) {
                    for (FoodItemsClass y : DataConverter.getInstance().getFoodItemsObservableArrayList()) {
                        if (x.getMenu_item_id().equals(y.getFoodItemId())) {
                            foodList.append(y.getFoodItemName()).append(" x").append(x.getQuantity()).append(", ");
                            Log.d("foodlist", foodList.toString());
                        }
                    }
                }
            }

            View cardView = getLayoutInflater().inflate(R.layout.check_order_status_card, null);

            cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            int marginLeft = 5;
            int marginTop = 0;
            int marginRight = 5;
            int marginBottom = 25;
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
            layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

            TextView orderStatusCardOrderID = cardView.findViewById(R.id.orderStatusCardOrderID);
            orderStatusCardOrderID.setText("Order #" + i.split(";")[0]);

            TextView orderStatusCardStatus = cardView.findViewById(R.id.orderStatusCardStatus);
            if (i.split(";")[1].equals("1")) {
                orderStatusCardStatus.setText("Order Status: Pending");
            } else if (i.split(";")[1].equals("2")) {
                orderStatusCardStatus.setText("Order Status: In Progress");
            } else {
                orderStatusCardStatus.setText("Order Status: Completed");
            }
            TextView orderStatusFoodOrderedData = cardView.findViewById(R.id.orderStatusFoodOrderedData);
            orderStatusFoodOrderedData.setText(foodList.toString());
            container.addView(cardView);
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setupDashboard() {
        PieChart pieChart = findViewById(R.id.dashboardPieChart);

        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.rgb(255, 102, 0));      // Orange
        colors.add(Color.rgb(51, 153, 255));      // Blue
        colors.add(Color.rgb(255, 51, 204));      // Pink
        colors.add(Color.rgb(0, 204, 102));    // Green
        colors.add(Color.rgb(255, 153, 51));    // Yellow-Orange
        colors.add(Color.rgb(102, 0, 204));    // Purple
        colors.add(Color.rgb(0, 153, 153));    // Teal

        ArrayList<PieEntry> entries = new ArrayList<>();
        LocalDate currentDate = LocalDate.now();

        float totalpaymentAmount = 0f;
        for (int i = 0; i < 7; i++) {
            LocalDate entryDate = currentDate.minusDays(i);
            float paymentAmount = 0f;

            for (PaymentClass payment : DataConverter.getInstance().getPaymentObservableArrayList()) {
                if (entryDate.equals(LocalDate.parse(payment.getPayment_date())) && (payment.getCust_id().equals(SessionManager.getInstance().get("cust_id")))) {
                    paymentAmount += Float.parseFloat(payment.getAmount());
                    totalpaymentAmount += Float.parseFloat(payment.getAmount());
                }
            }

            if (paymentAmount != 0f) {
                entries.add(new PieEntry(paymentAmount, entryDate.toString()));
            }
        }
        if (totalpaymentAmount == 0f) {
            entries.add(new PieEntry(1f, "No Payment Made"));
        }
        PieDataSet pieDataSet = new PieDataSet(entries, "7 Days PieChart");
        pieDataSet.setColors(colors);

        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);

        Legend legend = pieChart.getLegend();
        legend.setEnabled(false);

        pieChart.getDescription().setEnabled(false);
        pieChart.animateY(1000);
        pieChart.invalidate();

        LinearLayout container = findViewById(R.id.dashboardTransactionContainer);
        container.removeAllViews();

        for (PaymentClass i : DataConverter.getInstance().getPaymentObservableArrayList()) {
            if (i.getCust_id().equals(SessionManager.getInstance().get("cust_id"))) {
                View cardView = getLayoutInflater().inflate(R.layout.dashboard_card, null);

                cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                int marginLeft = 5;
                int marginTop = 0;
                int marginRight = 5;
                int marginBottom = 25;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
                layoutParams.setMargins(marginLeft, marginTop, marginRight, marginBottom);

                TextView transactionCardPaymentID = cardView.findViewById(R.id.transactionCardPaymentID);
                transactionCardPaymentID.setText("Payment ID: " +i.getPayment_id());

                TextView dashboardTransactionDateCard = cardView.findViewById(R.id.dashboardTransactionDateCard);
                dashboardTransactionDateCard.setText(i.getPayment_date());

                TextView dashboardOrderIDTransactionCard = cardView.findViewById(R.id.dashboardOrderIDTransactionCard);
                dashboardOrderIDTransactionCard.setText("Order ID #" +i.getOrder_id());

                TextView transactionHistoryAmountCard = cardView.findViewById(R.id.transactionHistoryAmountCard);
                transactionHistoryAmountCard.setText(i.getAmount());

                container.addView(cardView);
            }
        }
    }
}

