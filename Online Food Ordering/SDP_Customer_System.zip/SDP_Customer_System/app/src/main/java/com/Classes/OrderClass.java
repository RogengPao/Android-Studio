package com.Classes;

public class OrderClass {
    private String order_id;
    private String order_date;
    private String overall_total_price;
    private String quantity;
    private String sub_total_price;
    private String rest_id;
    private String cust_id;
    private String order_status_id;
    private String menu_item_id;

    public OrderClass(String order_id, String order_date, String overall_total_price, String quantity, String sub_total_price, String rest_id, String cust_id, String order_status_id, String menu_item_id) {
        this.order_id = order_id;
        this.order_date = order_date;
        this.overall_total_price = overall_total_price;
        this.quantity = quantity;
        this.sub_total_price = sub_total_price;
        this.rest_id = rest_id;
        this.cust_id = cust_id;
        this.order_status_id = order_status_id;
        this.menu_item_id = menu_item_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public String getOverall_total_price() {
        return overall_total_price;
    }

    public void setOverall_total_price(String overall_total_price) {
        this.overall_total_price = overall_total_price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getSub_total_price() {
        return sub_total_price;
    }

    public void setSub_total_price(String sub_total_price) {
        this.sub_total_price = sub_total_price;
    }

    public String getRest_id() {
        return rest_id;
    }

    public void setRest_id(String rest_id) {
        this.rest_id = rest_id;
    }

    public String getCust_id() {
        return cust_id;
    }

    public void setCust_id(String cust_id) {
        this.cust_id = cust_id;
    }

    public String getOrder_status_id() {
        return order_status_id;
    }

    public void setOrder_status_id(String order_status_id) {
        this.order_status_id = order_status_id;
    }

    public String getMenu_item_id() {
        return menu_item_id;
    }

    public void setMenu_item_id(String menu_item_id) {
        this.menu_item_id = menu_item_id;
    }
}
