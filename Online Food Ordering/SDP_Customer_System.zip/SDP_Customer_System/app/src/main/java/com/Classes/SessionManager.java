package com.Classes;

import java.util.HashMap;

public class SessionManager {
    private static SessionManager instance;

    private final HashMap<String, Object> data;

    private SessionManager(){
        data = new HashMap<>();
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void set(String key, Object value) {
        data.put(key, value);
    }

    public Object get(String key) {
        return data.get(key);
    }

    public void clear() {
        data.clear();
    }
}
