package com.Classes;

public class FoodItemsClass {
    private String foodItemId;

    private String foodItemName;

    private String foodItemDescription;

    private String foodPrice;

    private String food_availability;

    private String food_category;

    private String food_rest_id;



    public FoodItemsClass(String foodItemId, String foodItemName, String foodItemDescription, String foodPrice, String food_availability, String food_category, String food_rest_id) {
        this.foodItemId = foodItemId;
        this.foodItemName = foodItemName;
        this.foodItemDescription = foodItemDescription;
        this.foodPrice = foodPrice;
        this.food_availability = food_availability;
        this.food_category = food_category;
        this.food_rest_id = food_rest_id;
    }

    public String getFood_category() {
        return food_category;
    }

    public void setFood_category(String food_category) {
        this.food_category = food_category;
    }

    public String getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(String foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getFoodItemName() {
        return foodItemName;
    }

    public void setFoodItemName(String foodItemName) {
        this.foodItemName = foodItemName;
    }

    public String getFoodItemDescription() {
        return foodItemDescription;
    }

    public void setFoodItemDescription(String foodItemDescription) {
        this.foodItemDescription = foodItemDescription;
    }

    public String getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(String foodPrice) {
        this.foodPrice = foodPrice;
    }

    public String getFood_availability() {
        return food_availability;
    }

    public void setFood_availability(String food_availability) {
        this.food_availability = food_availability;
    }

    public String getFood_rest_id() {
        return food_rest_id;
    }

    public void setFood_rest_id(String food_rest_id) {
        this.food_rest_id = food_rest_id;
    }
}
