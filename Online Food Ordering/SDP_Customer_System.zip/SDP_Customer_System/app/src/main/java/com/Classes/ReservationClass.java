package com.Classes;

public class ReservationClass {
    private String reserve_id;
    private String reserve_name;
    private String number_pax;
    private String reserve_date;
    private String reserve_time;
    private String remarks;
    private String reserve_rest_id;
    private String cust_id;
    private String approvement;

    public ReservationClass(String reserve_id, String cust_id,String reserve_name, String number_pax, String reserve_date, String reserve_time, String reserve_rest_id, String approvement) {
        this(reserve_id, cust_id,reserve_name, number_pax, reserve_date, reserve_time,"-", reserve_rest_id, approvement);

    }



    public ReservationClass(String reserve_id, String cust_id, String reserve_name, String number_pax, String reserve_date, String reserve_time, String remarks, String reserve_rest_id, String approvement) {
        this.reserve_id = reserve_id;
        this.cust_id = cust_id;
        this.reserve_name = reserve_name;
        this.number_pax = number_pax;
        this.reserve_date = reserve_date;
        this.reserve_time = reserve_time;
        this.remarks = remarks;
        this.reserve_rest_id = reserve_rest_id;
        this.approvement = approvement;
    }

    public String getReserve_id() {
        return reserve_id;
    }

    public void setReserve_id(String reserve_id) {
        this.reserve_id = reserve_id;
    }

    public String getReserve_name() {
        return reserve_name;
    }

    public void setReserve_name(String reserve_name) {
        this.reserve_name = reserve_name;
    }

    public String getNumber_pax() {
        return number_pax;
    }

    public void setNumber_pax(String number_pax) {
        this.number_pax = number_pax;
    }

    public String getReserve_date() {
        return reserve_date;
    }

    public void setReserve_date(String reserve_date) {
        this.reserve_date = reserve_date;
    }

    public String getReserve_time() {
        return reserve_time;
    }

    public void setReserve_time(String reserve_time) {
        this.reserve_time = reserve_time;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getReserve_rest_id() {
        return reserve_rest_id;
    }

    public void setReserve_rest_id(String reserve_rest_id) {
        this.reserve_rest_id = reserve_rest_id;
    }

    public String getCust_id() {
        return cust_id;
    }

    public void setCust_id(String cust_id) {
        this.cust_id = cust_id;
    }

    public String getApprovement() {
        return approvement;
    }

    public void setApprovement(String approvement) {
        this.approvement = approvement;
    }
}
