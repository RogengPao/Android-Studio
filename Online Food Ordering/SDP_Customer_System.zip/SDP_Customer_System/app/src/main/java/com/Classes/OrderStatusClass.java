package com.Classes;

public class OrderStatusClass {
    private String order_status_id;
    private String order_status;

    public OrderStatusClass(String order_status_id, String order_status) {
        this.order_status_id = order_status_id;
        this.order_status = order_status;
    }

    public String getOrder_status_id() {
        return order_status_id;
    }

    public void setOrder_status_id(String order_status_id) {
        this.order_status_id = order_status_id;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }
}
