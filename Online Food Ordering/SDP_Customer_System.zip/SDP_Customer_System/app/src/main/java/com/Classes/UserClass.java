package com.Classes;

public class UserClass {
    private String cust_id;
    private String cust_fname;
    private String cust_lname;
    private String cust_email;
    private String cust_password;

    public UserClass(String cust_id, String cust_fname, String cust_lname, String cust_email, String cust_password) {
        this.cust_id = cust_id;
        this.cust_fname = cust_fname;
        this.cust_lname = cust_lname;
        this.cust_email = cust_email;
        this.cust_password = cust_password;
    }

    public String getCust_id() {
        return cust_id;
    }

    public void setCust_id(String cust_id) {
        this.cust_id = cust_id;
    }

    public String getCust_fname() {
        return cust_fname;
    }

    public void setCust_fname(String cust_fname) {
        this.cust_fname = cust_fname;
    }

    public String getCust_lname() {
        return cust_lname;
    }

    public void setCust_lname(String cust_lname) {
        this.cust_lname = cust_lname;
    }

    public String getCust_email() {
        return cust_email;
    }

    public void setCust_email(String cust_email) {
        this.cust_email = cust_email;
    }

    public String getCust_password() {
        return cust_password;
    }

    public void setCust_password(String cust_password) {
        this.cust_password = cust_password;
    }
}
