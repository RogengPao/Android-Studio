package com.Classes;

public class PaymentClass {
    private String payment_id;
    private String amount;
    private String payment_date;
    private String cust_id;
    private String order_id;

    public PaymentClass(String payment_id, String amount, String payment_date, String cust_id, String order_id) {
        this.payment_id = payment_id;
        this.amount = amount;
        this.payment_date = payment_date;
        this.cust_id = cust_id;
        this.order_id = order_id;
    }

    public String getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(String payment_id) {
        this.payment_id = payment_id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(String payment_date) {
        this.payment_date = payment_date;
    }

    public String getCust_id() {
        return cust_id;
    }

    public void setCust_id(String cust_id) {
        this.cust_id = cust_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
}
